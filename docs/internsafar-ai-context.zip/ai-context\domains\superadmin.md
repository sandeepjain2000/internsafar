# Domain: SuperAdmin

## Responsibility

Platform oversight: employer approvals (incl. Reject/Suspend), documents, Adjust Points, postings, posting share rewards, login report, feature ideas, messages, bootstrap.

## Central sources

| Path | Role |
|------|------|
| `src/app/superadmin/**` | Pages |
| `src/app/api/ip/superadmin/**` | SuperAdmin APIs (incl. `points`, `employers`, `documents`) |
| `src/app/api/ip/bootstrap/` | Demo/bootstrap ensure |
| `src/lib/ensureIpBootstrap.js` | Bootstrap helper |
| Login | Home `/` (same form as other roles); `/superadmin/login` redirects to `/` |

## Pages (confirmed)

| Route | Purpose |
|-------|---------|
| `/superadmin` | Dashboard |
| `/superadmin/login` | Redirect-only → `/` (no SA form) |
| `/superadmin/approvals` | **Only** employer approval queue (Domain + Free-email). Path column on rows. **Reject** and **Suspend** available for approved employers (not only pending). |
| `/superadmin/documents` | Documents (active rows only: `superseded_at IS NULL`) |
| `/superadmin/postings` | Postings oversight |
| `/superadmin/promotions` | Posting Share Rewards (LinkedIn posting-share claims) |
| `/superadmin/points` | **Adjust Points** — manual add/deduct on candidate or employer `ip_users.points`; floor 0; no cap; optional note; in-app notify user only (not advertised on user UIs) |
| `/superadmin/login-report` | Login report (default **All time**; not wiped by core reset) |
| `/superadmin/listing-reports` | Candidate listing reports (status open / reviewed / dismissed) |
| `/superadmin/messages` | Messages |
| `/superadmin/feature-ideas` | Feature ideas |

Retired (redirect → `/superadmin`): `/superadmin/viral` (orphaned viral-shares queue; APIs/table may remain).  
Retired (redirect → `/superadmin/approvals`): `/superadmin/form-registrations`, `/superadmin/requests`.  
APIs for those queues return **410**. Schema dropped on bootstrap: `ip_employer_requests`, `ip_users.form_approval_status` (`ensureIpRetireDeadQueuesSchema`).

Live employer onboarding = Domain / Free-email → Approvals only. Candidate register = Google path only (`path=form` → 410).

Employer email verify resend: `POST /api/ip/auth/employer-email-verify/resend` (login + post-register UI). Candidates do **not** use this verify gate.

**Suspend vs Reject:** both block login; keep as distinct `approval_status` values (`suspended` \| `rejected`). Do not collapse them.

Nav order: `src/lib/ipNav.js` → `SUPERADMIN_NAV`.

## Email unsubscribe queue (API)

| Path | Role |
|------|------|
| `GET` `/api/ip/superadmin/unsubscribe-requests` | List PENDING (and related) unsubscribe requests |
| Public `/unsubscribe?token=…` + `/api/ip/unsubscribe` | User click creates **PENDING** row — does **not** disable mail until ops process it |
| Libs | `src/lib/ipEmailUnsubscribe.js`, `ipEmailUnsubscribeFormat.js` |

There is **no** dedicated SuperAdmin page route for unsubscribe as of 2026-09-18 — consume via API / existing requests tooling. Confirm UI before inventing a page.

## Confirmed demo account (from `README.md`)

Bootstrap via `/api/ip/bootstrap` ensures: `support@placementhub.online` / `Admin@123`.  
Do not invent alternate admin roles. Do not reset password hashes for existing SuperAdmin in bootstrap.

## Constraints

- SuperAdmin shares the home login `/`; SuperAdmin layout `loginHref` is `/`.
- Restore (Suspended → approved) keeps the earlier Final Approval and skips the document check (sticky approval); the API only allows Suspend from approved, so every suspended employer already passed Final Approval.
- Treat approval/document/points flows as sensitive; inspect API auth checks before changes.
- Migration `036_ip_single_superadmin.sql` encodes single-superadmin data repair — read before changing admin user model.
- Final Approval still needs ≥1 approved active doc and no pending active docs (`assertDocumentsReadyForFinalApproval`).

## Related domains

Auth, Employer (approvals), Database, UI/UX.

## Inspect before modifying

Superadmin page, matching API, and shared approval/document/points helpers.
