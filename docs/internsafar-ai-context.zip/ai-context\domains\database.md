# Domain: Database

## Responsibility

Postgres access for InternSafar, `ip_*` schema, SQL migrations, migrate safety gates, runtime `ensure*` schema helpers.

## Central sources

| Path | Role |
|------|------|
| `src/lib/db.js` | `pg` pool — app queries must use **`ip_*` only** |
| `db/migrations/` | Numbered SQL (prefer `*ip*`; latest **`050_ip_employer_docs_reminders.sql`**) |
| `scripts/MIGRATION_MANIFEST.txt` | Apply order for Path C / sql-only |
| `docs/ip-er-diagram-notes.md` | ER notes (synced through **039**; also see **040–044**) |
| `docs/ip-er-diagram.puml` | PlantUML diagram |
| `scripts/schema-fingerprint-ip.mjs` | Read-only local↔AWS schema compare |
| `scripts/db_exec_sql_file.js` | Applies one SQL file (gated). Records applied files in `ip_schema_migrations` (filename, sha256 checksum) and skips them on re-run; `--force` re-runs, `--baseline` records without executing. DBs without the table behave as before (everything runs once, then is recorded) |
| `scripts/assert-db-migrate-allowed.js` | Blocks migrate unless allowed |
| `scripts/assert-db-migrate-target.js` | Blocks laptop/Vercel migrate against AWS RDS hostnames. Checks the explicit `connectionString` when given (`db_exec_sql_file.js` passes the one it connects with); otherwise blocks if **any** of `IP_DATABASE_URL` / `DATABASE_URL` / `SUPABASE_DATABASE_URL` (env or `.env*`) is RDS |
| `scripts/assert-migration-sql-safe.js` | Blocks destructive SQL in new migrations |
| `scripts/deploy-fresh-aws-db.mjs` | Path C fresh/empty RDS |

Useful npm scripts: `db:migrate:ip`, `db:migrate:sql-only`, `db:migrate:workbench`, `db:migrate:pipeline`, partial migrate scripts, `deploy:fresh-aws-db`, `db:check-migration-safety`, `db:check-integrity`.

## Notable recent migrations / runtime schema

| File / ensure | What it adds |
|---------------|----------------|
| `040_ip_help_chat_analytics.sql` | Help-chat analytics |
| `041_ip_email_unsubscribe_requests.sql` | Unsubscribe tokens/requests |
| `042_ip_country_region_fields.sql` | Candidate `country`, employer `hq_country` |
| `043_ip_ref_countries.sql` | `ip_ref_countries` catalog |
| `044_ip_internship_stipend_range.sql` | `ip_internships.stipend_inr_max` (+ CHECK) |
| `045_ip_notification_archive.sql` + `ensureIpNotificationCategorySchema` | `ip_notifications.archived_at` (NULL = Inbox; no blank-fill needed) |
| `046_ip_offer_withdrawn_status.sql` | Widens `ip_offers_status_check` with `withdrawn` (applied to Supabase and AWS 2026-09-29; no blank-fill; app falls back to `expired` on any DB still missing it) |
| `026b_ip_runtime_tables_before_constraints.sql` (2026-10-03) | Additive: creates runtime tables/columns that 027/028 constrain (`ip_users.two_factor_enabled`, `ip_2fa_challenges`, `ip_notification_preferences`, `ip_notifications.meta`) so a fresh migrate no longer fails. No-op on existing DBs |
| `047_ip_captcha_nonces_2fa_attempts.sql` + `ensureIpCaptchaNonceSchema` / `ensureIpTwoFactorSchema` (2026-10-03) | `ip_captcha_nonces` (single-use captcha) + `ip_2fa_challenges.failed_attempts` (default 0). Also created at runtime — optional on AWS, no blank-fill |
| `048_ip_lookup_indexes.sql` (2026-10-03) | Additive `CREATE INDEX IF NOT EXISTS`: `ip_notifications(user_id, created_at DESC)`, `ip_message_threads(candidate_user_id)` + `(employer_user_id)`, `ip_offers(candidate_id)`, `ip_applications(candidate_id)`. Performance only — app works without it; **not applied** to Supabase or AWS yet |
| `049_ip_users_core_account.sql` + `ensureIpCoreAccountSchema` (2026-10-08) | `ip_users.is_core_account BOOLEAN NOT NULL DEFAULT false` — shared demo logins whose password ignores UI changes (see `domains/auth.md`). Default false keeps every existing account normal (no blank-fill). Flag set with `npm run ip:core-account -- --mark=<email>`: done on Supabase (local/Vercel) for the core candidate + employer 2026-10-08; **AWS done 2026-10-08** (column + the same two flags by SQL in one transaction; users 10, core 2) |
| `050_ip_employer_docs_reminders.sql` + `ensureIpEmployerDocsReminderSchema` (2026-10-08) | `ip_employer_docs_reminders` — one row per employer, `employer_id` PK + FK → `ip_employers(id)` ON DELETE CASCADE; `sent_count` (CHECK ≥ 0), `first_sent_at`, `last_sent_at`, `manual_contact_at`, `last_error`, `last_error_at`. Weekly docs reminder tracking (`domains/employer.md`). No blank-fill (no row = never reminded). Created at runtime on Supabase 2026-10-08; **AWS created by SQL 2026-10-08** (one row so far: Samantha Hurk `manual_contact_at` 2026-10-08, `sent_count` 0) |
| Runtime columns (2026-10-03, Medium audit) | `ip_2fa_challenges.bind_hash`; `ip_email_unsubscribe_requests.processed_at` / `processed_by`; `ip_employers.approval_reviewed_by`; `ip_internships.moderated_by` / `moderated_at`; `ip_employer_documents.reviewed_by`. All nullable, added by `ensure*` helpers on first use; old rows stay NULL (no blank-fill needed — NULL means "before audit columns") |
| `035` self-check (edited 2026-10-03) | Order / summary-mismatch checks scoped to the three seeded cast candidates, so real users' histories cannot fail a deploy |
| `037`/`038` college-name retire (edited 2026-10-03) | UPDATEs only touch rows with `updated_at` before 2026-09-02 IST, so a replay cannot rewrite newer user edits |
| `ensureIpEmployerDocumentSlotsSchema` | `superseded_at`, `doc_label`, file_size; dedupe; active-type unique index |
| `ensureIpEmployerEmailVerifySchema` | Verify table + `email_verify_required` (**schema only**) |

## Blank-fill (not grandfather flags) — confirmed 2026-09-23

When AWS lacks columns that local/Vercel already have:

1. ADD schema (additive).
2. One-time **temp runner** fills blanks so **existing working accounts keep today’s behaviour** (e.g. set `email_verified_at` where null).
3. New signups use normal app paths.
4. Delete the temp runner after run.
5. **Forbidden:** `email_verify_required=false` (or similar) so code “ignores blanks.”

Workspace plan for next AWS push (outside app tree): `aws deploy/AWS-PUSH-PLAN-SCHEMA-BACKFILL-2026-10-08.md` (049 + 050, no blank-fill; **executed 2026-10-08** — AWS schema now matches local/Vercel again). General steps: `domains/deployment.md` → "General runbook".

## Environments ↔ database

| Host | Database |
|------|----------|
| Local | Shared Supabase Postgres / `DATABASE_URL` from `.env.local` — **transaction pooler, port 6543** (switched 2026-09-29) |
| Vercel (this sibling project) | **Same DB as local**; Vercel `DATABASE_URL` should also use port 6543 (session pooler 5432 caps all processes at 15 → `EMAXCONNSESSION`) |
| Production (`internsafar.com` / AWS) | **Separate** RDS only — no Supabase pooler; unaffected |

Transaction-mode safe: app uses no session features (no session `SET`, temp tables, LISTEN/NOTIFY, named prepared statements). Apply capacity lock is `pg_advisory_xact_lock` inside `BEGIN` (transaction-scoped — OK). `src/lib/db.js` still retries connect on connection-limit errors.

## Constraints

| Situation | Rule |
|-----------|------|
| Path B AWS app-only update | **Never** Path C / full migrate runner |
| Sibling needs columns AWS lacks | Explicit ADD + blank-fill **before** relying on those columns in prod |
| Path C fresh empty RDS | `IP_ALLOW_DB_MIGRATE=1 npm run deploy:fresh-aws-db` only |
| Live schema change | Explicit user request + additive / data-preserving SQL + gates |
| New migration SQL | No `DELETE FROM` / `DROP TABLE` / `TRUNCATE` / wipe-and-reinsert patterns |
| Table invention | Forbidden — read migrations / ER notes first |
| Env files | Never wipe `.env` / `.env.local` |

## Related domains

Auth, all feature domains, Deployment.

## Inspect before modifying

Target migration SQL, migrate gates, ensure helpers, and every query/lib that uses the affected tables. Fingerprint AWS vs local before Path B when schema-touching.
