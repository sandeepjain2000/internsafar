# Stable project decisions (InternSafar)

Only confirmed, durable decisions. Not a chat diary.  
Last pack refresh: 2026-10-16.

| Decision | Domain | Status | Evidence |
|----------|--------|--------|----------|
| Product tables are `ip_*` only; do not alter Placement Hub / `ism_*` | Database | Confirmed | `README.md`, `src/lib/db.js`, route inventory |
| Three roles: candidate, employer, superadmin | Auth / product | Confirmed | `ISM_ROUTE_INVENTORY.md`, `src/lib/ipNav.js` |
| No `middleware.js`; APIs are the security boundary; `PortalShell` is client guard | Auth | Confirmed | `ISM_ROUTE_INVENTORY.md`, absence of `middleware.js` |
| Signed in with the wrong role → `PortalShell` "Wrong account for this workspace" block (signed-in email + Sign out), URL stays; no redirect (403-style, matches Next.js `forbidden()` / OWASP). Tests assert the block page, not a URL change | Auth / testing | Confirmed 2026-10-07 | `src/components/ip/PortalShell.jsx`, `qa/tests/auth.spec.js`, `qa/tests/session-refresh.spec.js`, PERM-2 in `scripts/run-internsafar-qa.mjs` |
| Edit/deploy sibling `internship-portal`; nested mono copy is frozen | Workspace | Confirmed | Dual-folder workspace rule |
| Sibling app has its own `.git`; nested copy remains frozen regardless | Workspace | Confirmed | Live tree 2026-09-15 |
| Path B AWS update never migrates DB; Path C only on empty RDS with allow env | Deployment | Confirmed | `AGENTS.md`, Path B rule |
| New migrations must not wipe live rows | Database | Confirmed | Migration safety scripts + rule |
| Gemini HTML mocks → InternSafar UI (not Placement Hub) unless user says otherwise | UI | Confirmed | `gemini-tsx-handoff` workspace rule |
| Google register = verification; linked Google home sign-in opens portal session | Auth | Confirmed | `domains/testing.md`, auth helpers |
| S3 uploads under `internship-portal/…` prefix | Files | Confirmed | `README.md` |
| Local + Vercel share one Neon DB; production AWS is a separate DB | Database / Deploy | Confirmed | `domains/database.md` |
| Single InternSafar QA workbook SoT = `test-cases/InternSafar-Test-Cases.xlsx`; Boarders xlsx = format only | Testing | Confirmed | `domains/testing.md` |
| Live NIM help-chat completion = manual-only; GET/empty POST/UI smoke = automated | Testing | Confirmed | `domains/testing.md`, `regression.spec.js` |
| Canonical QA OTP env = `IP_QA_2FA_*` + `IP_QA_EMAIL_CHANGE_CODE`; CI skips/bypass when unset | Testing | Confirmed | `.env.example`, QA scripts |
| Bare `qa:e2e` does not force google-auth+regression; use `qa:e2e:regression` / `--suite=regression` | Testing | Confirmed | `qa/runners/run-internsafar.mjs`, `package.json` |
| `PRODUCT.md` / `DESIGN.md` named in `AGENTS.md` but missing — use `AGENTS.md` UI block + skills | UI | Confirmed gap | Live tree 2026-09-15 |
| Email unsubscribe link creates a **PENDING** SuperAdmin request only; does **not** stop mail delivery yet; URL uses `token` only (no email in query) | Mail / SuperAdmin | Confirmed | Migration `041_*`, `ipEmailUnsubscribe.js`, `/unsubscribe`, `mail.js` footers |
| Do not create dummy accounts. A dummy account is a non-real user with a fake email (`@example.com`, `@example.org`, `@example.net`, `@acme-example.com`, `example` / `*.example`, made-up Outlook, or any mailbox the project does not own). Those addresses bounce. Tests use an alias of a real mailbox: `alias1`–`alias5@placementhub.online`, `placementhubsupport+qa-freemail@gmail.com`, or `lawsonlclintern+qa…`. The `sendMail` drop is only a backstop | Testing / Mail | Confirmed 2026-10-17 | `domains/testing.md` “No dummy accounts”, `src/lib/mail.js` |
| Reserved test domains never reach the mail provider. `sendMail` drops `@example.com`, `@example.org`, `@example.net`, `@acme-example.com`, their subdomains, and any domain that is `example` or ends in `.example`. If no deliverable recipient remains, the provider is not called (`reason: 'reserved-test-domain'`) and the caller still gets success so signup can keep the verification link. A real address on the same send is still delivered | Mail | Confirmed 2026-10-16 | `src/lib/mail.js` `isReservedTestEmail`, `scripts/test-ip-mail-override.mjs` |
| Shared client list paging uses `IpListPager` (+ `ip-list-pager.css`) on candidate/employer list surfaces | UI | Confirmed | `IpListPager.jsx`; internships/offers/notifications/messages |
| v3 code-review prompts omit Accessibility (FE-ACC / a11y) from review + remediation | Process | Confirmed | `prompt-test-extract/…/code-review-prompt_version3.txt`, user 2026-09-18 |
| 2026-09-18 review remediation: Valid **Critical** + Valid **High** (non-a11y) fixed on sibling and deployed to Vercel preview; **Medium/Low** + all a11y remain open | Process / Quality | Confirmed | GPT triage DOCX + sibling working tree + Vercel deploy 2026-09-18 |
| Agents must **Read** `docs/ai-context/PROJECT_INDEX.md` on chat startup (and before IP search/edit); rule text alone is not enough | Process / Agents | Confirmed | `.cursor/rules/internsafar-ai-context-pack.mdc`, `AGENTS.md` ai-context-pack block |
| Profile/registration label = **Country**; list filters label = **Region**. Options live in DB table `ip_ref_countries` (migration `043_*`) and `/api/ip/ref/countries`, with static fallback in `src/lib/ipRegions.js`: India, Pakistan, Bangladesh, Sri Lanka, Nepal, Indonesia, Malaysia, Thailand. Phone dial dropdown uses the **same country set** via `IP_COUNTRY_PHONE_DIALS` / `ipPhoneValidation.js` (not US/UK/etc.). Candidate browse filters employer `hq_country`; employer search filters candidate `country` via `region` query. | Candidate / Employer | Confirmed | `ip_ref_countries`, `useIpCountryCatalog`, `IP_COUNTRY_PHONE_DIALS`, migration `043_*` |
| Live Employer Register (Domain + Free Email) → `/superadmin/approvals` Only; Form Registrations + Manual Requests UI Retired; Candidates Have No SA Approval Queue; Path Column Uses `registration_source` | SuperAdmin / Auth | Confirmed | Live Register Proof 2026-09-23; `register-employer`, Redirects, `ipNav.js` |
| Final Employer Approval Requires Documents First (At Least One Approved Doc, No Pending Docs); Documents Approve Does Not Alone Unlock Login/Posting | SuperAdmin / Employer | Confirmed | `employers/[id]` Gate 2026-09-23 |
| Employer Guidelines & Ethics: Accept/Reject UI; lock after all Accepted + saved (`ethics_accepted_at`); API rejects revoke; SA `resetEthics` unlock; posting gate requires saved ethics | Employer / SuperAdmin | Confirmed | Profile + `ipEmployerPostingGate` + SA employers PATCH 2026-09-25 |
| Employer profile uses employer-specific Tabs (Company / Contact & Location / About & Visibility / Ethics / Documents); Country→State→City→Phone; logo URL hidden when image set | Employer / UI | Confirmed | `employer/profile/page.js` 2026-09-25 |
| Employer may sign in after email verification while still pending Final Approval (to upload docs); Postings nav/API stay gated until approved | Auth / Employer | Confirmed | `auth.js` + employer layout 2026-09-23 |
| Employer email-verify QA exposure via `IP_QA_EMPLOYER_EMAIL_VERIFY_TOKEN_IN_RESPONSE` (token + mail metadata in register JSON); hard-off when `VERCEL_ENV=production`; employers use form password (no temp-password mail) | Testing / Auth | Confirmed | `ipQaEmployerRegister.js`, `qa-employer-reg-verify-approve-login.mjs`, `docs/qa-employer-register-e2e.md` |
| Employer email verify resend (login + post-register); cooldown ~45s; candidates have no verify-before-login | Auth | Confirmed | `employer-email-verify/resend`, `IpSignInLanding`, `EmployerRegisterClient` |
| Form candidate path + manualRequest employer queue retired (410); drop `ip_employer_requests` + `form_approval_status` via bootstrap | Auth / SuperAdmin | Confirmed | `ensureIpRetireDeadQueuesSchema.js` |
| **Core accounts are never touched by testing.** Core = exactly three (`PROTECTED_ACCOUNT_EMAILS` in `ipCoreSampleConfig.js`): SuperAdmin `support@placementhub.online`, candidate `lawsonlclintern+1@gmail.com`, employer `placementhubsupport@gmail.com`; `+2`/`+3` aliases are filler, not core. No test transactions on the core candidate / employer; demos only. Testing uses disposable test accounts (`scripts/lib/ipTestAccountsConfig.js`) dropped by the reset and re-created by `npm run qa:ensure-test-accounts` / Playwright global setup. No separate test SuperAdmin: the one SuperAdmin acts on test accounts but is never itself changed by tests. Supersedes the older "cores for login smoke" allowance | Testing | Confirmed (owner 2026-10-07) | `domains/testing.md` §7; incident Nova Labs suspend/reject 2026-09-29/30 |
| QA/seed accounts must use realistic varied personas | Testing | Confirmed | `ipQaRealisticPersonas.mjs`, workspace rule `qa-test-account-variety` |
| AWS email-verify: ADD schema + one-time fill `email_verified_at=created_at` for existing employers; **no** `email_verify_required=false` grandfather (temp runner deleted after run) | Auth / Deploy | Confirmed | Applied AWS RDS 2026-09-23; `ensureIpEmployerEmailVerifySchema` schema-only |
| Schema gaps on live AWS: fill blanks with values that preserve current behaviour; **never** invent parallel “ignore blank” flags | Database / Deploy | Confirmed | Workspace rule `schema-blank-fill-not-grandfather-flags`; plan `aws deploy/AWS-PUSH-PLAN-SCHEMA-BACKFILL-2026-09-26.md` |
| Employer verification docs: **one active row per type** (Shop Act / LLP / Business PAN / Other+label); re-upload supersedes prior (`superseded_at`) and resets to pending; Final Approval / SA queues count **active** docs only | Employer / SuperAdmin | Confirmed | `ipEmployerDocuments.js` Hybrid E 2026-09-26 |
| SuperAdmin **Adjust Points** (`/superadmin/points`): manual add/deduct on candidate or employer `ip_users.points` (same currency, per-account balance); no cap; deduct cannot go below 0; optional note; user gets in-app “Admin has added/removed X points” only — feature not advertised on candidate/employer UI | SuperAdmin / Points | Confirmed | `api/ip/superadmin/points` 2026-09-26; note optional `82ead1b` |
| SA Approvals: **Reject** and **Suspend** for approved employers (distinct statuses; both block login) | SuperAdmin / Auth | Confirmed | Approvals UI + employers API 2026-09-26 |
| Employer **HQ Country** = single-select (aligned with State), not multi-select chips | Employer / UI | Confirmed | `employer/profile` + `SearchableSelect` 2026-09-26 |
| Internship stipend **range**: `stipend_inr` floor/fixed + optional `stipend_inr_max` (NULL = single amount); migration `044_*` | Employer / Database | Confirmed | `044_ip_internship_stipend_range.sql`, posting new/edit 2026-09-26 |
| Posting gate requires approved + email verified + ethics saved (current ack IDs) + profile_complete | Employer | Confirmed | `ipEmployerPostingGate.js` 2026-09-26 |
| Notifications: candidate/employer **archive** (Inbox / Archived via `archived_at`), never delete; `DELETE /api/ip/notifications` is SuperAdmin-only | Workflow / SuperAdmin | Confirmed | `045_ip_notification_archive.sql`, notifications API 2026-09-28 |
| Latest sibling product on Vercel Production as of 2026-09-26: commit `82ead1b` | Deploy | Confirmed | `vercel ls` Ready |

## Do Not Add Here

- One-off bug fixes, CSS tweaks, temporary experiments
- Speculative roadmap items
- Secrets, PEM contents, or credential values
