# Related workspace folders (InternSafar context pack)

These folders sit beside the sibling app under the parent workspace `UIUX Migration/`.

**Source of truth for running code:** `internship-portal/` only.  
**Folder tree inside the app:** `FOLDER_STRUCTURE.md`.  
Open the folders below only when the task needs them.

| Folder | Role | When to open |
|--------|------|----------------|
| `internship-portal` | Live edit + Vercel deploy tree | Always for product work |
| `internship-portal-aws-handoff` | AWS deploy pack (prefer no secrets) | AWS Path B/C, EC2, migrate gates |
| `internship-portal-aws-handoff-WITH-SECRETS` | Handoff that may contain secrets | Ops only — never echo secrets into chat/docs |
| `latets projet cdoe for aws deploy` | Extra/older AWS handoff copy + zip | Compare/history if primary handoff unclear |
| `aws deploy` | Guides, tarballs, PEM, problem notes; **AWS schema/backfill push plans** `AWS-PUSH-PLAN-SCHEMA-BACKFILL-<date>.md` (last schema plan 2026-10-08, executed) and app-only plans `AWS-PUSH-PLAN-<date>.md` (latest executed 2026-10-17, no schema, no blank-fill) + read-only compare script `schema-check-2026-10-08/ro-prod-safety-check.mjs` | First-time setup / redeploy / AWS blank-fill planning |
| `Aws deployment documents` | Formal runbook / setup / update DOCX | Human runbooks — summarize, don’t dump |
| `gemini-tsx-handoff` | Gemini HTML mocks + assets/logo | UI redesign from mocks |
| `mobile csreens internsafar` | Mobile HTML handoff package. `INTERNSAFAR_MOBILE_HANDOFF_PACKAGE/` = 4 Sep Gemini mocks (unchanged). `FINAL_MOBILE_REFERENCE_UPDATED-2026-10-10/` = 33 screens + patterns redrawn from the live phone views (≤767px), per-screen "Changed since 4 Sep" + "Live phone check" notes, README lists live phone bugs; rebuild with `node _build/build.mjs` | Mobile UI redesign / phone-view fixes |
| `mobile-prompt-test` | Mobile prompt experiments | Mobile prompt/compare work |
| `qa-samples-for-internsafar` | Sample QA / nested IP / Playwright bits | Sampling only — not the primary app |
| `_local-backups-internship-portal` | Dated page/UI backups | Restore/compare old UI only |
| `task-docs` | InternSafar change/UX notes | Feature placement / showcase notes |
| `prompts` | Prompt DOCX library (workspace; Google Drive catalog via Master Document Links); testing prompts listed below | Finding / editing Cursor prompts; writing or auditing test cases |
| `new prompt files` | Design-system / handoff prompt drafts | New prompt authoring |
| `prompt-test-extract` | Unpacked `v3_prompts` + `code-review-final` + no-secrets IP zip extract + review outputs | Testing / iterating code-review prompts; **not** the live edit tree |
| `Development prompts for cursor to use` | Plan / build / verify standing prompts | Plan / build / verify modes |
| `Read me and txt copies that are renamed` | IP requirements + migration prompt copies | Requirements / migration script prompts |

## Workspace root files

| Path (under `UIUX Migration/`) | Role |
|--------------------------------|------|
| `InternSafar_Business_Requirements.txt` | Business requirements (BRD) |
| `Development prompts for cursor to use/` | Standing Cursor operating prompts |
| `Internship-Portal-Code-Review-Triage-FINAL.docx` | GPT triage of v3 HTML/JSON review (Critical/High/Med/Low + Valid flags) |
| `prompt-test-extract/internship-portal/reviews/internship-portal-2026-09-18-v3-report.{html,json}` | Evidence report from v3 prompt run on the extract tree |

Also mirrored in-app: `internship-portal/InternSafar_Business_Requirements.txt`. If copies differ, note the difference; prefer the one the user points at.

### Code-review prompt testing (2026-09-18)

| Path | Role |
|------|------|
| `prompt-test-extract/v3_prompts/` | Guardrail / step prompts (session → scope → test+lint → extract → audit → report) |
| `prompt-test-extract/code-review-final/` | Build-system prompt (`code-review-prompt_version3.txt`) for FE/BE/API layered report structure |
| `prompt-test-extract/internship-portal/` | No-secrets extract used as review target (map `src/` UI as frontend; `src/app/api` + `server/lib` as backend/API; root `package.json` for lint/test) |
| Live sibling `internship-portal/` | Where Critical/High remediations were applied and Vercel-deployed |

**Do not edit product code in `prompt-test-extract/internship-portal` for shipping.** Ship from the sibling only.

## Testing prompts library (in-app)

| Path | Role |
|------|------|
| `internship-portal/prompts/` | Full prompts library (Development, Mobile, Projects, Testing, UI Design, Websites) |
| `internship-portal/prompts/Testing/` | Test creation, frontend/backend QA prompts, regression checklists |
| `…/prompts/Testing/test-case-generation-prompts.txt` | Generic SaaS case-design prompts (meta-prompt + suites such as the E2E / smoke matrix); design only, no results |
| `…/prompts/Testing/Use the manual-test-case-generator.txt` | Manual QA case prompt: every case traces to code-visible behaviour; happy / negative / edge / permission / regression; no invented behaviour or secrets |
| `…/prompts/Testing/backend_qa_prompt v3.pdf`, `frontend_qa_prompt v3.pdf` | Backend / frontend QA review prompts |
| `…/prompts/Testing/boarders_latest_update_test_checklist.xlsx` | **Format reference only** for regression checklists |
| `…/prompts/Testing/Enrolment Admin test cases.xlsx`, `Web_ticketing_test_checklist (2).xlsx` | Example workbooks from other products (format only) |

## Testing prompts library (workspace, added to the pack 2026-10-10)

Under `UIUX Migration/prompts/` (DOCX copies of the same rules plus test-plan skills). Use with the in-app folder above when writing, auditing or retiring workbook cases.

| Path (under `UIUX Migration/prompts/`) | Role |
|------|------|
| `PROMPT (QA test plan and test making).md` | Combined InternSafar QA prompt: risk-based test plan with requirement → case matrix, test data, then four-bucket verify report |
| `test-case-generation-prompts.docx` | DOCX of the in-app case-writing rules |
| `Use the manual-test-case-generator.docx` | DOCX of the in-app manual case template |
| `SKILL.md(test plan generation).docx`, `SKILL.md(test generation).docx` | Test plan / test generation skills |
| `PROMPT (Code review v3 - test+lint execution).docx` | Test + lint step of the code-review prompts (four-bucket reporting) |
| `_build_testing_cortex_docs.mjs` | Builds the testing DOCX copies |

Domain guide: `domains/testing.md`.

## Explicitly out of product-edit scope

| Path | Rule |
|------|------|
| `campus-placement-multiuser/internship-portal` | Frozen nested copy — do not edit or deploy from here |
| `campus-placement-multiuser/src/…` | Placement Hub — not InternSafar unless the user says otherwise |

## Deep reference inside the app repo (on demand)

| Doc | Use |
|-----|-----|
| `ISM_ROUTE_INVENTORY.md` | Full route/API inventory |
| `ISM_USER_GUIDE.md` | Role behaviour |
| `InternSafar_Business_Requirements.txt` | In-app BRD copy |
| `WORKBENCH_FEATURE_GUIDE.md` | Employer workbench |
| `scripts/SCRIPTS-README.md` | Scripts catalogue |
| Handoff `AWS-DEPLOY.md`, `PATH-B-NO-DB-MIGRATE.txt` | AWS procedures |
